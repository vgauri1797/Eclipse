define({
  "group": "Nome",
  "openAll": "Abrir todos num painel",
  "dropDown": "Exibir no menu pendente",
  "noGroup": "Não está definido qualquer grupo de widgets.",
  "groupSetLabel": "Definir as propriedades de grupos de widgets"
});