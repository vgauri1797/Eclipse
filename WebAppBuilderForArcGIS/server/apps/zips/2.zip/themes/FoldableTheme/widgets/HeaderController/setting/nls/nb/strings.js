define({
  "group": "Navn",
  "openAll": "Åpne alle i ett panel",
  "dropDown": "Vis i rullegardinmeny",
  "noGroup": "Det finnes ikke noe widgetgruppesett.",
  "groupSetLabel": "Angi egenskaper for widgetgrupper"
});