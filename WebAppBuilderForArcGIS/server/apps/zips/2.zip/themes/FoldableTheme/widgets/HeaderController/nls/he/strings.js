define({
  "_widgetLabel": "בקר כותרת",
  "signin": "התחבר",
  "signout": "התנתק",
  "about": "אודות",
  "signInTo": "התחבר אל",
  "cantSignOutTip": "פונקציה זו אינה זמינה במצב תצוגה מקדימה.",
  "more": "עוד"
});