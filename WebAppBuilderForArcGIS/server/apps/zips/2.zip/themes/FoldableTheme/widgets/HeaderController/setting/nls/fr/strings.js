define({
  "group": "Nom",
  "openAll": "Tout ouvrir dans un volet",
  "dropDown": "Afficher dans le menu déroulant",
  "noGroup": "Aucun groupe de widgets n’est défini.",
  "groupSetLabel": "Définir les propriétés des groupes de widgets"
});