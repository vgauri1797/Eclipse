define({
  "_themeLabel": "Preklopiva tema",
  "_layout_default": "Zadani izgled",
  "_layout_layout1": "Izgled 1"
});